import React from "react";
import MainDashboard from "./MainDashboard.jsx";

const Dashboard = () => {
  return (
    <div>
      <div>
        <MainDashboard />
      </div>
    </div>
  );
};

export default Dashboard;
