import React from "react";

const Profile = () => {
  return <div className="h-screen w-full p-10">Profile</div>;
};

export default Profile;
