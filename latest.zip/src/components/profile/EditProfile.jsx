import React from "react";

const EditProfile = () => {
  return <div className="h-screen w-full p-10">EditProfile</div>;
};

export default EditProfile;
