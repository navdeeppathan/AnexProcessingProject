import container from "../assets/containerImg.jpg";

export const ImgContainer = {
  container,
};
