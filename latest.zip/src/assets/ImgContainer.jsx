import container from "../assets/containerImg.jpg";
import logo from "../assets/logo.png";
export const ImgContainer = {
  container,
  logo,
};
